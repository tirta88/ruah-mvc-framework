<?php $this->setSiteTitle('Bad Token'); ?>
<?php $this->start('body'); ?>
<h1 class="text-center red">Your token is corrupted.</h1>
<?php $this->end(); ?>
